@echo off
title CATENGINE Launcher v1.0
color 1b
echo ========================================
echo            (CATENGINE made by Miaou_555)
echo         CATENGINE - LAUNCHER           
echo (v1.0)
echo ========================================
echo Starting CATENGINE...
echo.
echo (WARNING: DO NOT CLOSE THIS WINDOW, IT WILL CLOSE THE GAME WITH IT.)
:: Run python directly (using python instead of start so the CMD stays open to show errors/server prompts)
python engine.py
color 1b
echo.
echo [NOTICE] CATENGINE session has ended.
pause