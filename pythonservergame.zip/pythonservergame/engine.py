import socket
import threading
import sys
import os
from ursina import *

# --- NETWORK & SERVER CHECKING LOGIC ---
PORT = 7777

def check_server(ip, port):
    if ip.lower() in ('localhost', '127.0.0.1'):
        target_ip = '127.0.0.1'
    else:
        target_ip = ip

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(2.0)
    try:
        s.connect((target_ip, port))
        s.close()
        return 'ONLINE'
    except ConnectionRefusedError:
        return 'UNAVAILABLE'
    except (socket.timeout, socket.gaierror, OSError):
        return 'NONEXISTENT'
    finally:
        s.close()

def run_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        server_socket.bind(('0.0.0.0', PORT))
        server_socket.listen(5)
        print(f"[SERVER] Hosting multiplayer server on port {PORT}...")
        while True:
            conn, addr = server_socket.accept()
    except Exception as e:
        print(f"[SERVER ERROR] {e}")

# --- MAIN GAME SETUP ---
def main():
    print("========================================")
    print("         CATENGINE - 3D SANDBOX         ")
    print("========================================")
    
    ip_input = input("Enter Server IP to join (press Enter for localhost): ").strip()
    if not ip_input:
        ip_input = "127.0.0.1"

    print(f"Checking status of {ip_input}...")
    status = check_server(ip_input, PORT)

    is_hosting = False

    if status == 'ONLINE':
        print(f"[SUCCESS] Connected to server at {ip_input}!")
    elif status == 'UNAVAILABLE':
        print(f"[ERROR] The server at {ip_input} exists, but is currently offline (Unavailable).")
        sys.exit(1)
    elif status == 'NONEXISTENT':
        print(f"[NOTICE] The server at {ip_input} does not exist or cannot be reached.")
        choice = input("Would you like to host a new server on this IP? (y/n): ").strip().lower()
        if choice == 'y':
            is_hosting = True
            server_thread = threading.Thread(target=run_server, daemon=True)
            server_thread.start()
            print("[HOST] Server started successfully. Launching game...")
        else:
            print("Exiting engine.")
            sys.exit(0)

    # --- INITIALIZE 3D GRAPHICS & ENGINE UI ---
    app = Ursina()

    window.title = "CATENGINE"
    window.borderless = False
    window.fps_counter.enabled = True

    mouse.locked = False
    mouse.visible = False

    # --- CUSTOM TEXTURE MOUSE CURSOR SYSTEM (Half Size) ---
    idle_tex = 'assets/textures/ui/mouses/idle.png'
    hover_tex = 'assets/textures/ui/mouses/hover.png'
    type_tex = 'assets/textures/ui/mouses/type.png'

    base_cursor_scale = 0.04  # Halved from previous size

    custom_cursor = Entity(
        parent=camera.ui,
        model='quad',
        texture=idle_tex if os.path.exists(os.path.join(sys.path[0], 'assets', 'textures', 'ui', 'mouses', 'idle.png')) else 'white_cube',
        scale=(base_cursor_scale, base_cursor_scale),
        origin=(0, 0),
        z=-100
    )

    # --- PLAYER CHARACTER WITH TRUE CHARACTER ORBIT & LIMBS ---
    class CatEngineCharacter(Entity):
        def __init__(self, **kwargs):
            super().__init__()
            # Root avatar entity positioned on spawn pad
            self.avatar = Entity(position=(0, 0, 0))
            
            # Construct Blocky Limbs (Classic Style)
            self.torso = Entity(parent=self.avatar, model='cube', color=color.cyan, scale=(1.2, 1, 0.6), position=(0, 1.6, 0))
            self.head = Entity(parent=self.avatar, model='cube', color=color.yellow, scale=(0.8, 0.8, 0.8), position=(0, 2.5, 0))
            self.left_arm = Entity(parent=self.avatar, model='cube', color=color.yellow, scale=(0.6, 1, 0.6), position=(-0.9, 1.6, 0))
            self.right_arm = Entity(parent=self.avatar, model='cube', color=color.yellow, scale=(0.6, 1, 0.6), position=(0.9, 1.6, 0))
            self.left_leg = Entity(parent=self.avatar, model='cube', color=color.green, scale=(0.6, 1, 0.6), position=(-0.3, 0.6, 0))
            self.right_leg = Entity(parent=self.avatar, model='cube', color=color.green, scale=(0.6, 1, 0.6), position=(0.3, 0.6, 0))

            # Physics & Movement state
            self.velocity_y = 0
            self.is_grounded = True
            
            # True Character Orbit Parameters
            self.distance = 10
            self.orbit_x = 15
            self.orbit_y = 0
            self.mouse_sensitivity = 150
            self.walk_timer = 0

            # Audio Paths
            self.walk_sound_path = os.path.join(sys.path[0], 'assets', 'audio', 'character', 'walk.wav')
            self.jump_sound_path = os.path.join(sys.path[0], 'assets', 'audio', 'character', 'jump.wav')

        def update(self):
            # Directional movement relative to camera look direction
            cam_forward = Vec3(camera.forward.x, 0, camera.forward.z).normalized()
            cam_right = Vec3(camera.right.x, 0, camera.right.z).normalized()

            move_dir = Vec3(
                cam_right * (held_keys['d'] - held_keys['a']) +
                cam_forward * (held_keys['w'] - held_keys['s'])
            )

            if move_dir.length() > 0:
                move_dir = move_dir.normalized()
                self.avatar.position += move_dir * time.dt * 6
                
                # Procedural walk cycle animation (swinging limbs)
                walk_cycle = sin(time.time() * 15) * 30
                self.left_arm.rotation_x = walk_cycle
                self.right_arm.rotation_x = -walk_cycle
                self.left_leg.rotation_x = -walk_cycle
                self.right_leg.rotation_x = walk_cycle

                # Footstep sound trigger
                self.walk_timer += time.dt
                if self.is_grounded and self.walk_timer > 0.4:
                    self.walk_timer = 0
                    if os.path.exists(self.walk_sound_path):
                        Audio(self.walk_sound_path, volume=0.5, autoplay=True)
            else:
                # Smoothly return limbs to idle posture when stopped
                self.left_arm.rotation_x = lerp(self.left_arm.rotation_x, 0, time.dt * 10)
                self.right_arm.rotation_x = lerp(self.right_arm.rotation_x, 0, time.dt * 10)
                self.left_leg.rotation_x = lerp(self.left_leg.rotation_x, 0, time.dt * 10)
                self.right_leg.rotation_x = lerp(self.right_leg.rotation_x, 0, time.dt * 10)

            # Apply gravity and vertical physics
            if not self.is_grounded:
                self.velocity_y -= 22 * time.dt

            self.avatar.y += self.velocity_y * time.dt

            # Baseplate collision boundary check
            if self.avatar.y <= 0:
                self.avatar.y = 0
                self.velocity_y = 0
                self.is_grounded = True

            # Hold RIGHT-CLICK + Move Mouse to ORBIT around character avatar
            if held_keys['right mouse']:
                self.orbit_y += mouse.velocity[0] * self.mouse_sensitivity
                self.orbit_x -= mouse.velocity[1] * self.mouse_sensitivity
                self.orbit_x = clamp(self.orbit_x, -10, 85)

            # Calculate true spherical camera position orbiting the character center
            char_center = self.avatar.position + Vec3(0, 1.5, 0)
            camera.rotation = (self.orbit_x, self.orbit_y, 0)
            camera.position = char_center - (camera.forward * self.distance)

            # Responsive cursor scaling & positioning
            dynamic_scale = (window.size[1] * 0.00012) * 4
            custom_cursor.scale = (dynamic_scale, dynamic_scale)
            custom_cursor.position = (mouse.x, mouse.y)

            # Dynamic cursor state detection based on UI hover
            hit_info = mouse.hovered_entity
            if hit_info and isinstance(hit_info, InputField):
                if os.path.exists(type_tex):
                    custom_cursor.texture = type_tex
            elif hit_info and (isinstance(hit_info, Button) or hasattr(hit_info, 'on_click')):
                if os.path.exists(hover_tex):
                    custom_cursor.texture = hover_tex
            else:
                if os.path.exists(idle_tex):
                    custom_cursor.texture = idle_tex

        def input(self, key):
            # Spacebar jump handling
            if key == 'space' and self.is_grounded:
                self.velocity_y = 8.5
                self.is_grounded = False
                if os.path.exists(self.jump_sound_path):
                    Audio(self.jump_sound_path, volume=0.7, autoplay=True)
            elif key == 'scroll up':
                self.distance -= 1.5
                self.distance = clamp(self.distance, 3, 25)
            elif key == 'scroll down':
                self.distance += 1.5
                self.distance = clamp(self.distance, 3, 25)

    # --- DYNAMIC SKYBOX LOADER ---
    sky_path = os.path.join(sys.path[0], 'assets', 'textures', 'lighting', 'skies')
    sky_loaded = False
    if os.path.exists(sky_path):
        sky_files = [f for f in os.listdir(sky_path) if f.lower().endswith(('.png', '.jpg', '.jpeg'))]
        if sky_files:
            try:
                Sky(texture=os.path.join('assets', 'textures', 'lighting', 'skies', sky_files[0]))
                sky_loaded = True
                print(f"[SKYBOX] Loaded sky texture: {sky_files[0]}")
            except Exception as e:
                print(f"[SKYBOX ERROR] Failed to load texture: {e}")
                
    if not sky_loaded:
        Sky(color=color.white)
        print("[SKYBOX] No custom sky textures found. Defaulting to blank white sky.")

    # Classic UI Overlay & CoreGUI Menu Button
    top_bar = Entity(parent=camera.ui, model='quad', color=color.dark_gray, scale=(2, 0.08), y=0.46)
    title_text = Text(text="CATENGINE v1.0", parent=camera.ui, x=-0.85, y=0.44, scale=1.2, color=color.white)
    mode_label = Text(text=f"Mode: {'Hosting' if is_hosting else 'Joined Client'} ({ip_input})", parent=camera.ui, x=0.4, y=0.44, scale=1, color=color.yellow)

    # CoreGUI Menu Button with icon and text
    menu_icon_path = os.path.join(sys.path[0], 'assets', 'textures', 'ui', 'menu', 'menuicon.png')
    menu_button = Button(
        parent=camera.ui,
        text='  MENU',
        color=color.rgb(70, 70, 80),
        scale=(0.12, 0.05),
        x=-0.82,
        y=0.46
    )
    menu_icon_entity = Entity(
        parent=menu_button,
        model='quad',
        texture=menu_icon_path if os.path.exists(menu_icon_path) else 'white_cube',
        scale_x=0.25,
        scale_y=0.8,
        x=-0.28,
        z=-1
    )

    # Instructions overlay
    info_text = Text(text="Hold RIGHT-CLICK + Move to Orbit Character | Space to Jump | Scroll to Zoom | WASD to move", parent=camera.ui, x=-0.65, y=-0.44, scale=1, color=color.black)

    # --- DEFAULT MAP: BASEPLATE & SPAWNPOINT ---
    baseplate = Entity(
        model='cube',
        color=color.rgb(48, 48, 48),
        scale=(100, 1, 100),
        position=(0, -0.5, 0),
        collider='box'
    )

    spawn_pad = Entity(
        model='cube',
        color=color.rgb(255, 220, 0),
        scale=(6, 0.2, 6),
        position=(0, 0.01, 0),
        collider='box'
    )
    spawn_text = Text(text="SPAWN", position=(-0.4, 0.1), billboard=True, color=color.black)
    spawn_text.world_position = (0, 1.5, 0)

    # Lighting
    DirectionalLight(y=2, z=3, rotations=(45, 45, 0), color=color.rgb(220, 220, 220))
    AmbientLight(color=color.rgb(100, 100, 100))

    # Initialize Player Character
    player = CatEngineCharacter()

    app.run()

if __name__ == '__main__':
    main()