@echo off
title CATENGINE Requirement Installer v1.0
color 1b
echo ========================================
echo (CATENGINE REQ. INST. made by Miaou_555)
echo    CATENGINE - REQUIREMENT INSTALLER           
echo (v1.0)
echo ========================================
echo Starting Installer...
echo.
echo (WARNING: DO NOT CLOSE THIS WINDOW, IT MIGHT CORRUPT THE DOWNLOADING IF NOT FINISHED)
:: Run python directly (using python instead of start so the CMD stays open to show errors/server prompts)
pip install ursina
color 1b
echo.
echo [NOTICE] Installer session has ended.
pause